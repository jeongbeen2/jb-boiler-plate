module.exports = {
  login: require('./users/login'),
  accessTokenRequest: require('./users/accessTokenRequest'),
  signup: require('./users/signup'),
};
